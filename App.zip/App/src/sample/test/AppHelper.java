package sample.test;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppHelper extends SQLiteOpenHelper {
	
	Context context;
	
	public AppHelper(Context context) {
		super(context, "sidewalkcafe.db", null, 1);
		this.context = context;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub

		String statements[] = {
				"CREATE TABLE cafe ("
					+ "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "name TEXT,"
					+ "address TEXT"
					+ ");",
				
				"INSERT INTO cafe (_id, name, address) VALUES (260, 'ROLL-N-ROASTER CORP.','2901,EMMONS AVENUE,BROOKLYN,NY');",
				"INSERT INTO cafe (_id, name, address) VALUES (170, 'NECTAR RESTAURANT CORP','1090,MADISON AVENUE,NY,NY');",
				"INSERT INTO cafe (_id, name, address) VALUES (500,'STAGE DELICATESSEN & RESTAURANT INC.','7 AVENUE,832-834 7 AVE,NY,NY');",
				"INSERT INTO cafe (_id, name, address) VALUES (422,'FORTUNATO BROS.CAFE & BAKERY CORP','289,MANHATTAN AVENUE,BROOKLYN,NY');"
			};
			
			for (String statement: statements) {
				db.execSQL(statement);
			}
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}
	
	public Cursor getCafe() {
		
		String sql = "SELECT * FROM cafe;";
		SQLiteDatabase db = getReadableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		cursor.moveToFirst();
		return cursor;
	}

}
