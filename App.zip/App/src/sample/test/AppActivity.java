package sample.test;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

public class AppActivity extends Activity {
	
	AppHelper helper;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        helper = new AppHelper(this);
        Cursor cursor = helper.getCafe();
        Spinner s1 = (Spinner) findViewById(R.id.spinner1);
        
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
    			this,
    			android.R.layout.simple_list_item_1,
    			cursor,
    			new String[] {"name"},
    			new int[] {android.R.id.text1}	//TextView in simple_list_item_1.xml
    		);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        s1.setAdapter(adapter);

        
    }
}